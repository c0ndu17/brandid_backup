(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RouteController = Package['iron-router'].RouteController;
var Route = Package['iron-router'].Route;
var Router = Package['iron-router'].Router;

/* Package-scope variables */
var VisualCaptcha, frontendData;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/captcha/lib/index.js                                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var visualCaptcha = null;                                                                                        // 1
                                                                                                                 // 2
var VisualCaptcha = function(session) {                                                                          // 3
  this.session = session;                                                                                        // 4
}                                                                                                                // 5
                                                                                                                 // 6
VisualCaptcha.prototype.start = function(howmany) {                                                              // 7
    // After initializing visualCaptcha, we only need to generate new options                                    // 8
    if ( ! visualCaptcha ) {                                                                                     // 9
      visualCaptcha = Npm.require( 'visualcaptcha' )( this.session );                                            // 10
    }                                                                                                            // 11
    visualCaptcha.generate( howmany );                                                                           // 12
    return JSON.stringify(visualCaptcha.getFrontendData());                                                      // 13
                                                                                                                 // 14
}                                                                                                                // 15
                                                                                                                 // 16
VisualCaptcha.prototype.getAudio = function(res, type) {                                                         // 17
  // It's not impossible this method is called before visualCaptcha is initialized, so we have to send a 404     // 18
  if ( ! visualCaptcha ) {                                                                                       // 19
      return { error: true, errorCode: 404, errorMsg: 'Not Found' };                                             // 20
  } else {                                                                                                       // 21
    return visualCaptcha.getAudio( res, type);                                                                   // 22
  }                                                                                                              // 23
}                                                                                                                // 24
                                                                                                                 // 25
VisualCaptcha.prototype.getImage = function(index, retina, response) {                                           // 26
  var isRetina = false;                                                                                          // 27
                                                                                                                 // 28
  // It's not impossible this method is called before visualCaptcha is initialized, so we have to send a 404     // 29
  if ( ! visualCaptcha ) {                                                                                       // 30
      return { error: true, errorCode: 404, errorMsg: 'Not Found' };                                             // 31
  } else {                                                                                                       // 32
    // Default is non-retina                                                                                     // 33
    if ( retina ) {                                                                                              // 34
        isRetina = true;                                                                                         // 35
    }                                                                                                            // 36
    return visualCaptcha.getImage( index, response, isRetina);                                                   // 37
  }                                                                                                              // 38
                                                                                                                 // 39
}                                                                                                                // 40
                                                                                                                 // 41
VisualCaptcha.prototype.generate = function(num) {                                                               // 42
  return visualCaptcha.generate(num);                                                                            // 43
}                                                                                                                // 44
                                                                                                                 // 45
VisualCaptcha.prototype.getImageOptions = function() {                                                           // 46
  return visualCaptcha.getImageOptions();                                                                        // 47
}                                                                                                                // 48
                                                                                                                 // 49
VisualCaptcha.prototype.getValidImageOption = function() {                                                       // 50
  return visualCaptcha.getValidImageOptions();                                                                   // 51
}                                                                                                                // 52
                                                                                                                 // 53
VisualCaptcha.prototype.validateImage = function(sentOption) {                                                   // 54
  return visualCaptcha.validateImage(sentOption)                                                                 // 55
}                                                                                                                // 56
                                                                                                                 // 57
VisualCaptcha.prototype.validateAudio = function(opt) {                                                          // 58
  return visualCaptcha.validateAudio(opt);                                                                       // 59
}                                                                                                                // 60
                                                                                                                 // 61
VisualCaptcha.prototype.getFrontendData = function() {                                                           // 62
  return visualCaptcha.getFrontendData();                                                                        // 63
}                                                                                                                // 64
                                                                                                                 // 65
Meteor.VisualCaptcha = VisualCaptcha;                                                                            // 66
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/captcha/server/captcha.js                                                                            //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 1
  var session = {}; //global fake session for server side                                                        // 2
  var VisualCaptcha = (VisualCaptcha != undefined) ? VisualCaptcha : null;                                       // 3
  Meteor.startup(function () {                                                                                   // 4
    //Define the routes of the API                                                                               // 5
    Router.map(function () {                                                                                     // 6
      this.route("audio", {                                                                                      // 7
        path: "/captcha/audio/?:type?",                                                                          // 8
        where: 'server',                                                                                         // 9
        action: getAudio                                                                                         // 10
      });                                                                                                        // 11
      this.route("image", {                                                                                      // 12
        path: "/captcha/image/:index",                                                                           // 13
        where: 'server',                                                                                         // 14
        action: getImage                                                                                         // 15
      });                                                                                                        // 16
      this.route("start", {                                                                                      // 17
        path: "/captcha/start/:howmany",                                                                         // 18
        where: 'server',                                                                                         // 19
        action: start                                                                                            // 20
      });                                                                                                        // 21
    });                                                                                                          // 22
  });                                                                                                            // 23
  Meteor.methods({                                                                                               // 24
    validateCaptcha: function(data){                                                                             // 25
      var status;                                                                                                // 26
      // It's not impossible this method is called before VisualCaptcha is initialized, so we have to send a 404 // 27
      if ( ! VisualCaptcha ) {                                                                                   // 28
          status = 'noCaptcha';                                                                                  // 29
      } else {                                                                                                   // 30
          frontendData = VisualCaptcha.getFrontendData();                                                        // 31
          // If an image field name was submitted, try to validate it                                            // 32
          if ( data.name === frontendData.imageFieldName ) {                                                     // 33
              if ( VisualCaptcha.validateImage(data.value) ) {                                                   // 34
                  status = 'validImage';                                                                         // 35
              } else {                                                                                           // 36
                  status = 'failedImage';                                                                        // 37
              }                                                                                                  // 38
          } else if ( data.name === frontendData.audioFieldName ) {                                              // 39
              if ( VisualCaptcha.validateAudio(data.value.toLowerCase()) ) {// We set lowercase to allow case-insensitivity, but it's actually optional
                  status = 'validAudio';                                                                         // 41
              } else {                                                                                           // 42
                  status = 'failedAudio';                                                                        // 43
              }                                                                                                  // 44
          } else {                                                                                               // 45
              status = 'failedPost';                                                                             // 46
          }                                                                                                      // 47
          // We need to know how many images were generated before, to generate the same number again            // 48
          var howmany = VisualCaptcha.getImageOptions().length;                                                  // 49
          VisualCaptcha.generate( howmany );                                                                     // 50
          return status;                                                                                         // 51
      }                                                                                                          // 52
    }                                                                                                            // 53
  });                                                                                                            // 54
                                                                                                                 // 55
  function allowCORS(res) {                                                                                      // 56
    res.setHeader("access-control-allow-origin", "*");                                                           // 57
  }                                                                                                              // 58
                                                                                                                 // 59
  function getAudio() {                                                                                          // 60
    var type = this.params.type;                                                                                 // 61
    // It's not impossible this method is called before VisualCaptcha is initialized, so we have to send a 404   // 62
    allowCORS(this.response);                                                                                    // 63
    if ( ! VisualCaptcha ) {                                                                                     // 64
      this.response.writeHead(404);                                                                              // 65
      this.response.end('Not Found');                                                                            // 66
    } else {                                                                                                     // 67
      // Default file type is mp3, but we need to support ogg as well                                            // 68
      if ( type !== 'ogg' ) {                                                                                    // 69
          type = 'mp3';                                                                                          // 70
      }                                                                                                          // 71
                                                                                                                 // 72
      var result = VisualCaptcha.getAudio( this.response, type );                                                // 73
      if(!result.error) {                                                                                        // 74
        this.response.writeHead(200);                                                                            // 75
        this.response.end(result.audio);                                                                         // 76
      } else {                                                                                                   // 77
        this.response.writeHead(result.errorCode);                                                               // 78
        this.response.end(result.errorMsg);                                                                      // 79
      }                                                                                                          // 80
    }                                                                                                            // 81
  }                                                                                                              // 82
                                                                                                                 // 83
  function getImage() {                                                                                          // 84
    allowCORS(this.response);                                                                                    // 85
    try {                                                                                                        // 86
      var result = VisualCaptcha.getImage(this.params.index, this.request.query.retina, this.response);          // 87
      if(!result.error) {                                                                                        // 88
        this.response.writeHead(200);                                                                            // 89
        this.response.end(result.image);                                                                         // 90
      } else {                                                                                                   // 91
        this.response.writeHead(result.errorCode);                                                               // 92
        this.response.end(result.errorMsg);                                                                      // 93
      }                                                                                                          // 94
    } catch (er){                                                                                                // 95
      this.response.writeHead(400);                                                                              // 96
      this.response.end(er.toString());                                                                          // 97
    }                                                                                                            // 98
  }                                                                                                              // 99
                                                                                                                 // 100
  function start() {                                                                                             // 101
     // After initializing VisualCaptcha, we only need to generate new options                                   // 102
    allowCORS(this.response);                                                                                    // 103
    if ( ! VisualCaptcha ) {                                                                                     // 104
        VisualCaptcha = new Meteor.VisualCaptcha(session);                                                       // 105
    }                                                                                                            // 106
    this.response.writeHead(200);                                                                                // 107
    this.response.end(VisualCaptcha.start( this.params.howmany ));                                               // 108
  }                                                                                                              // 109
}                                                                                                                // 110
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.captcha = {
  VisualCaptcha: VisualCaptcha
};

})();
