(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var _ = Package.underscore._;
var HTML = Package.htmljs.HTML;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['blaze-layout'] = {};

})();
