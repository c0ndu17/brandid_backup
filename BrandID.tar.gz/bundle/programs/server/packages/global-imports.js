/* Imports for global scope */

RouteController = Package['iron-router'].RouteController;
Route = Package['iron-router'].Route;
Router = Package['iron-router'].Router;
VisualCaptcha = Package.captcha.VisualCaptcha;
Spiderable = Package.spiderable.Spiderable;
_ = Package.underscore._;
Accounts = Package['accounts-base'].Accounts;
Email = Package.email.Email;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
Log = Package.logging.Log;
Deps = Package.deps.Deps;
DDP = Package.livedata.DDP;
DDPServer = Package.livedata.DDPServer;
MongoInternals = Package['mongo-livedata'].MongoInternals;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
check = Package.check.check;
Match = Package.check.Match;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
SimpleSchema = Package['simple-schema'].SimpleSchema;
MongoObject = Package['simple-schema'].MongoObject;
HTML = Package.htmljs.HTML;
Spacebars = Package['spacebars-common'].Spacebars;

